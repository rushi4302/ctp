from fastapi import APIRouter

router = APIRouter(prefix="/municipality")


@router.get("")
def municipality_status() -> dict[str, str]:
    return {"module": "municipality", "status": "ready"}
