from fastapi import APIRouter

from app.api.v1.endpoints import (
    ai,
    auth,
    comments,
    contractor,
    likes,
    municipality,
    posts,
    search,
    users,
)

api_router = APIRouter()
api_router.include_router(auth.router, tags=["auth"])
api_router.include_router(users.router, tags=["users"])
api_router.include_router(posts.router, tags=["posts"])
api_router.include_router(comments.router, tags=["comments"])
api_router.include_router(likes.router, tags=["likes"])
api_router.include_router(search.router, tags=["search"])
api_router.include_router(municipality.router, tags=["municipality"])
api_router.include_router(contractor.router, tags=["contractor"])
api_router.include_router(ai.router, tags=["ai"])
