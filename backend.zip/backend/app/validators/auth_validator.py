"""Authentication-related validation helpers."""
