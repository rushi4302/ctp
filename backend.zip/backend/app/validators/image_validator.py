"""Image-related validation helpers."""
