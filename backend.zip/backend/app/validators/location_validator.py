"""Location-related validation helpers."""
