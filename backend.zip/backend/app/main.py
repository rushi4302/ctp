from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import text

from app.api.router import router
from app.core.config import settings
from app.database.session import engine


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        print(settings.database_url)
        print(engine.url)
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        print("✅ Database Connected Successfully!")
    except Exception as e:
        print("❌ Database Connection Failed!")
        print(e)

    yield


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    lifespan=lifespan,
)

# 👇 Add this
app.include_router(router)


@app.get("/")
def root():
    return {
        "message": "Backend is running!",
        "database": "Connected",
    }